# VMAXRAY DNA Trader — Android APK Build Guide
**Version:** 3.1.9 (VMAX32-TV1-9)
**Package:** com.vmaxray.trader
**Target:** Android 5.0+ (API 21+)

---

## Prerequisites

- Android Studio Hedgehog (2023.1.1) or newer — [developer.android.com/studio](https://developer.android.com/studio)
- JDK 17 (bundled with Android Studio)
- Android device with USB debugging enabled, OR Android emulator

---

## Project Structure

```
vmaxray-android/
├── app/
│   ├── src/main/
│   │   ├── assets/
│   │   │   └── vmaxray.html          ← VMAXRAY app (TV1-9 + Android bridge)
│   │   ├── java/com/vmaxray/trader/
│   │   │   └── MainActivity.java     ← WebView host + WakeLock + JS bridge
│   │   ├── res/values/
│   │   │   ├── strings.xml
│   │   │   └── styles.xml
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
└── settings.gradle
```

---

## Step 1 — Create Android Studio Project

1. Open Android Studio → **New Project**
2. Select **Empty Activity**
3. Set:
   - **Name:** VMAXRAY DNA Trader
   - **Package name:** `com.vmaxray.trader`
   - **Save location:** anywhere on your PC
   - **Language:** Java
   - **Minimum SDK:** API 21 (Android 5.0)
4. Click **Finish**

---

## Step 2 — Replace Project Files

Copy each file from this package into the Android Studio project:

| Source file | Destination in project |
|---|---|
| `MainActivity.java` | `app/src/main/java/com/vmaxray/trader/MainActivity.java` |
| `AndroidManifest.xml` | `app/src/main/AndroidManifest.xml` |
| `styles.xml` | `app/src/main/res/values/styles.xml` |
| `strings.xml` | `app/src/main/res/values/strings.xml` |
| `app/build.gradle` | `app/build.gradle` |
| `build.gradle` | `build.gradle` (root) |
| `settings.gradle` | `settings.gradle` |
| `vmaxray.html` | `app/src/main/assets/vmaxray.html` ← create `assets` folder if it doesn't exist |

**To create assets folder:**
Right-click `app/src/main` → New → Folder → Assets Folder → Finish

---

## Step 3 — Add App Icons (Optional but recommended)

Android Studio auto-generates icons. To use the default:
- Leave `@mipmap/ic_launcher` references as-is
- Android Studio will use its default launcher icon

To use a custom icon:
- Right-click `res` → New → Image Asset
- Upload a 512×512 PNG of the VMAXRAY logo

---

## Step 4 — Sync + Build

1. Click **File → Sync Project with Gradle Files**
2. Wait for Gradle sync to complete
3. Click **Build → Make Project** (Ctrl+F9)
4. If successful: **Build → Generate Signed Bundle/APK → APK**

---

## Step 5 — Install on Device

### Option A — USB (recommended for first install)
1. Enable Developer Options on your Android device:
   Settings → About Phone → tap **Build Number** 7 times
2. Enable **USB Debugging** in Developer Options
3. Connect USB cable
4. In Android Studio: click **Run** ▶ → select your device
5. App installs and launches automatically

### Option B — APK file transfer
1. Build APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. APK location: `app/build/outputs/apk/debug/app-debug.apk`
3. Transfer APK to phone (via USB, Google Drive, etc.)
4. On phone: Settings → Install unknown apps → allow your file manager
5. Tap the APK file to install

---

## Step 6 — CRITICAL: Battery Optimization (Do this after install)

Android aggressively kills background apps. To keep VMAXRAY running:

### Disable battery optimization for VMAXRAY:
Settings → Apps → VMAXRAY DNA Trader → Battery → **Unrestricted**
(exact path varies by Android version / manufacturer)

### Samsung devices:
Settings → Battery → Background usage limits → Never sleeping apps → Add VMAXRAY

### Xiaomi / MIUI:
Settings → Apps → Manage apps → VMAXRAY → Battery saver → **No restrictions**
Also: Security app → Battery → disable "Power-intensive prompts"

### OnePlus / OxygenOS:
Settings → Battery → Battery optimization → VMAXRAY → **Don't optimize**

---

## Step 7 — First Launch

1. Open VMAXRAY DNA Trader
2. App loads in full-screen WebView
3. Select a coin → tap Analyze
4. WebSocket connects to Binance streams
5. DNA engine starts processing live candles

---

## Technical Notes

### WebSocket keep-alive
The Android bridge injects a 25-second ping loop on every WebSocket connection.
On disconnect, auto-reconnect fires after 5 seconds (while `isLive = true`).

### WakeLock
`PARTIAL_WAKE_LOCK` keeps the CPU running when the screen turns off.
Renewed every 25 seconds via `Android.renewWakeLock()` called from JS heartbeat.
`FLAG_KEEP_SCREEN_ON` prevents screen sleep while app is in foreground.

### Timer protection
`setInterval` calls with delay < 50ms are floored to 50ms to prevent
WebView throttling crashes on older Android versions.

### Orientation
`android:screenOrientation="fullUser"` — follows the device's auto-rotate setting.
Both portrait and landscape layouts work (same as browser).

### Permissions summary
| Permission | Why |
|---|---|
| INTERNET | Binance WebSocket streams |
| ACCESS_NETWORK_STATE | `Android.isOnline()` check |
| WAKE_LOCK | CPU alive when screen off |
| FOREGROUND_SERVICE | Background service (Android 9+) |
| REQUEST_IGNORE_BATTERY_OPTIMIZATIONS | Bypass battery kill |

---

## Troubleshooting

| Problem | Fix |
|---|---|
| White screen on launch | Check `vmaxray.html` is in `assets/` folder |
| WebSocket not connecting | Check INTERNET permission in Manifest |
| App killed in background | Disable battery optimization (Step 6) |
| Screen turns off | Check FLAG_KEEP_SCREEN_ON + wake lock |
| Build error "resource not found" | Ensure styles.xml has both AppTheme + FullscreenTheme |
| `minifyEnabled` issues | Keep `minifyEnabled false` in release build |

---

## Version History

| Version | HTML base | Notes |
|---|---|---|
| 3.1.9 | VMAX32-TV1-9 | Initial APK port — WebView + WakeLock + Android bridge |
