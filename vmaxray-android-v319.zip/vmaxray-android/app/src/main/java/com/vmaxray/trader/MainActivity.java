package com.vmaxray.trader;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

public class MainActivity extends Activity {

    private WebView webView;
    private PowerManager.WakeLock wakeLock;
    private FrameLayout webViewContainer;

    // ── JavaScript → Android bridge ─────────────────────────────────────────
    private class VMAXRayInterface {
        private final MainActivity activity;

        VMAXRayInterface(MainActivity activity) {
            this.activity = activity;
        }

        @android.webkit.JavascriptInterface
        public void showToast(String message) {
            activity.runOnUiThread(() ->
                Toast.makeText(activity, message, Toast.LENGTH_SHORT).show());
        }

        @android.webkit.JavascriptInterface
        public boolean isOnline() {
            ConnectivityManager cm = (ConnectivityManager)
                activity.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo netInfo = cm.getActiveNetworkInfo();
            return netInfo != null && netInfo.isConnectedOrConnecting();
        }

        @android.webkit.JavascriptInterface
        public void logToAndroid(String message) {
            android.util.Log.d("VMAXRAY", message);
        }

        @android.webkit.JavascriptInterface
        public void renewWakeLock() {
            // Called from JS keep-alive to extend wake lock
            activity.runOnUiThread(() -> {
                if (wakeLock != null && !wakeLock.isHeld()) {
                    wakeLock.acquire(10 * 60 * 1000L);
                    android.util.Log.d("VMAXRAY", "WakeLock renewed from JS");
                }
            });
        }
    }

    // ── Activity lifecycle ───────────────────────────────────────────────────
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Hide system UI for true fullscreen
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );

        // Keep screen on while app is in foreground
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        // Build layout
        webViewContainer = new FrameLayout(this);
        webViewContainer.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));
        webView = new WebView(this);
        webView.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));
        webViewContainer.addView(webView);
        setContentView(webViewContainer);

        // Acquire partial wake lock (keeps CPU alive when screen off)
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "VMAXRay::TradingWakeLock"
        );
        if (!wakeLock.isHeld()) {
            wakeLock.acquire(10 * 60 * 1000L); // 10 min, renewed by JS ping
        }

        setupWebView();

        // Load the HTML from assets folder
        webView.loadUrl("file:///android_asset/vmaxray.html");
    }

    private void setupWebView() {
        WebSettings ws = webView.getSettings();

        // Core JS + storage
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);

        // Viewport / zoom
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setBuiltInZoomControls(true);
        ws.setDisplayZoomControls(false);

        // File + content access (needed for local asset HTML)
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);

        // Allow WSS streams from file:// origin (Android 5+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        // Render priority
        ws.setRenderPriority(WebSettings.RenderPriority.HIGH);

        // JS bridge — accessible as window.Android in HTML
        webView.addJavascriptInterface(new VMAXRayInterface(this), "Android");

        // WebViewClient
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                injectKeepAliveScript();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }
        });

        // Forward JS console → Android logcat
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage cm) {
                android.util.Log.d("WebView",
                    cm.message() + " [" + cm.sourceId() + ":" + cm.lineNumber() + "]");
                return true;
            }
        });
    }

    // ── Keep-alive injection ─────────────────────────────────────────────────
    private void injectKeepAliveScript() {
        String script =
            "(function() {" +
            "  if (window._vmaxKeepAliveInjected) return;" +
            "  window._vmaxKeepAliveInjected = true;" +
            "  console.log('VMAXRAY: Injecting keep-alive script');" +

            // 25s heartbeat — renews wake lock + logs to Android
            "  window._vmaxKeepAlive = setInterval(function() {" +
            "    try { if(window.Android) window.Android.renewWakeLock(); } catch(e) {}" +
            "    try { if(window.Android) window.Android.logToAndroid('heartbeat'); } catch(e) {}" +
            "  }, 25000);" +

            // requestAnimationFrame loop — prevents timer throttling
            "  if (!window._vmaxAnimLoop) {" +
            "    window._vmaxAnimLoop = function() {" +
            "      requestAnimationFrame(window._vmaxAnimLoop);" +
            "    };" +
            "    requestAnimationFrame(window._vmaxAnimLoop);" +
            "  }" +

            "  console.log('VMAXRAY: Keep-alive active');" +
            "})();";

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            webView.evaluateJavascript(script, null);
        } else {
            webView.loadUrl("javascript:" + script);
        }
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────
    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
        webView.resumeTimers();
        if (wakeLock != null && !wakeLock.isHeld()) {
            wakeLock.acquire(10 * 60 * 1000L);
        }
        injectKeepAliveScript();
    }

    @Override
    protected void onPause() {
        super.onPause();
        webView.onPause();
        // NOTE: Do NOT call webView.pauseTimers() — this kills WebSocket + DNA engine
    }

    @Override
    protected void onDestroy() {
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
        if (webView != null) {
            webViewContainer.removeView(webView);
            webView.removeAllViews();
            webView.destroy();
        }
        super.onDestroy();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
